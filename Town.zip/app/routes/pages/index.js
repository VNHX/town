module.exports = {
  path: 'all/',
  childRoutes: [
    require('./mainPage'),
  ]
};
