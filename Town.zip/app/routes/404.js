import NotFoundPage from "../components/common/NotFoundPage";

module.exports = {
  path: '*',
  component: NotFoundPage
};
