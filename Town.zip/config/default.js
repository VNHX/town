module.exports = {
  devPort: 8080,
  serviceBaseUrl: 'http://127.0.0.1:3000/',
};
